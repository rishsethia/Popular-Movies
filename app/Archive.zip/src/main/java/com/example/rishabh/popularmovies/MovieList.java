package com.example.rishabh.popularmovies;

import java.util.ArrayList;

/**
 * Created by Rishabh on 6/8/16.
 */
public class MovieList {


    // All the names of the model class should be same as the result received ! Else you are badly fucked up
    ArrayList<Movie> results;
}
